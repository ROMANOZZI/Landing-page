/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/
const partitions = document.querySelectorAll('section');
const UnorderedList = document.querySelector('ul');
const fragment = document.createDocumentFragment();
const Back = document.getElementById('button');
/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

//creating navbar
partitions.forEach(Partition => {
  //getting value
    const navData = Partition.getAttribute("data-nav");  
    //getting IdAttribute value from the section  
    const IdAttribute = Partition.getAttribute('id');

//creating new link
    const links = document.createElement("a");
//creating new list item
    const newli = document.createElement("li");

// add navbar style   
    links.classList.add("menu__link");
// get the href from the sections id
    links.setAttribute('href',IdAttribute);
// scrolling between the sections 
// Scrolling to section on link click
    links.addEventListener('click', e => {
        e.preventDefault();
        Partition.scrollIntoView({behavior : "smooth"})
    });
// getting section name 
    const txt = document.createTextNode(navData);

    links.appendChild(txt);  
    fragment.appendChild(newli);
    newli.appendChild(links);
    
  
    });
 
    UnorderedList.appendChild(fragment);

        window.addEventListener('scroll',()=>{

//   Checking What Is Section On Screen now
        const activeSection = document.getElementsByClassName('your-active-class')[0];

        if(activeSection !== undefined){
            activeSection.classList.remove('your-active-class')
        }
//   Checking What Is Section On Screen now 
        const navActive = document.getElementsByClassName('navactive')[0];

        if(navActive !== undefined){
            navActive.classList.remove('navactive')
        }
        //active section
        partitions.forEach(section => {

        const react = section.getBoundingClientRect();
    
        if(react.top >=-50 && react.top<394){
                                   
         section.classList.add('your-active-class');
       //active nav-Bar

         const activeList = document.querySelectorAll(`a[href='${section.id}']`)[0].parentElement;


         activeList.classList.add("navactive");
                

// Button
        if (section.id=="section1"){
            
                   Back.style.display = 'none';
        } else {
                   Back.style.display='block';

             }
         }
     })   
 })   
